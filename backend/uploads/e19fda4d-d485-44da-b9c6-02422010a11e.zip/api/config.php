<?php

define('KMA_ACCESS_TOKEN', '');
define('KMA_CHANNEL', '');
define('KMA_DEBUG', false);
